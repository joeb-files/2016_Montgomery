function [ FDMatrix ] = SetUpFDMatrix(BC,GM,h)
%This function populates a sparse matrix (FDMatrix) with the coupling
%coefficients from the geometric model (GM).  BC is the Dirichlet boundary
%condition and is generally equal to 0.  h is the voxel dimension (e.g.,
%h=0.1 mm)

[xL,yM,zN]=size(GM);

%CFace1-CFace6 are the "coupling coefficients" of voxels adjacent to each
%face of the voxel with the voxel itself.  CSelf is the self coupling
%coefficient.  This code populates each line of the FD matrix
%(corresponding to the potential in each cell of the GM model) with the
%coupling coefficients of each side.
CFace1=struct;
CFace2=struct;
CFace3=struct;
CFace4=struct;
CFace5=struct;
CFace6=struct;
CSelf=struct;

%% FDMatrix The following code populates the FD matrix with coupling 
%coefficents.  If the face is on the boundary it is assigned a value of BC
%(usually zero).
for k=1:zN
    for j=1:yM
        for i=1:xL
            idx=sub2ind([xL yM zN],i,j,k);%linear index of voxel of interest
            if k-1==0  
                
%%%%%%%%%%%%%%%%Find coefficient for face 1.  If it lies on the boundary
                %set the value equal to the boundary condition BC.
                CFace1(idx).val=BC;
                
            else
                %Else set the value to the conductivity (z component of the
                %adjacent voxel from the geometry model (GM)).
                CFace1(idx).val=GM{i,j,k-1}(3,3)*h;%(3,3) index is zz 
                %component of conductivity tensor
                
            end
            %The sub2ind command returns an error if the  location is
                %outside of the FD matrix.  The try/catch command catches
                %the error and sets the location to -1,-1 so the location
                %can be ignored
            try
                    CFace1(idx).loc=[sub2ind([xL yM zN],i,j,k)...
                        sub2ind([xL yM zN],i,j,k-1)];
            catch
                    CFace1(idx).loc=[-1 -1];
            end
 %%%%%%%%%%%%Face2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
            if  j+1>yM
                CFace2(idx).val=BC;
                
            else
                
                CFace2(idx).val=GM{i,j+1,k}(2,2)*h;%(2,2) index is yy 
                %component of conductivity tensor
            end
            
            try
                    CFace2(idx).loc=[sub2ind([xL yM zN],i,j,k)...
                        sub2ind([xL yM zN],i,j+1,k)];
            catch
                    CFace2(idx).loc=[-1 -1];
            end
 %%%%%%%%%%%%Face3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
            if i-1==0
                CFace3(idx).val=BC;
              
            else
                
                CFace3(idx).val=GM{i-1,j,k}(1,1)*h;%(1,1) index is xx
                %component of conductivity tensor;
                
            end
            
            try
                    CFace3(idx).loc=[sub2ind([xL yM zN],i,j,k)...
                        sub2ind([xL yM zN],i-1,j,k)];
            catch
                    CFace3(idx).loc=[-1 -1];
            end
                
 %%%%%%%%%%%%Face4%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                
            if j-1==0
                CFace4(idx).val=BC;
            else
                
                CFace4(idx).val=GM{i,j-1,k}(2,2)*h;%(2,2) index is yy 
                %component of conductivity tensor
                
            end
            try
                    CFace4(idx).loc=[sub2ind([xL yM zN],i,j,k)...
                        sub2ind([xL yM zN],i,j-1,k)];
            catch
                    CFace4(idx).loc=[-1 -1];
            end
                
 %%%%%%%%%%%%Face5%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if i+1>xL
                CFace5(idx).val=BC;
                 
            else
                 
                CFace5(idx).val=GM{i+1,j,k}(1,1)*h;%(1,1) indexes xx 
                %comp of cond tensor
            end
            
            try
                    CFace5(idx).loc=[sub2ind([xL yM zN],i,j,k)...
                        sub2ind([xL yM zN],i+1,j,k)];
            catch
                    CFace5(idx).loc=[-1 -1];
            end
            
 %%%%%%%%%%%%Face6%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            
            if k+1>zN
                CFace6(idx).val=BC;
                 
            else
                 
                CFace6(idx).val=GM{i,j,k+1}(3,3)*h;%(1,1) indexes xx 
                %comp of cond tensor
            end
            try
                    CFace6(idx).loc=[sub2ind([xL yM zN],i,j,k)...
                        sub2ind([xL yM zN],i,j,k+1)];
            catch
                    CFace6(idx).loc=[-1 -1];
            end
            
%% MixedBC   The following code sets up the mixed boundary condition for 
%voxels on the boundary of the space
      if k-1==0 %Test to see if the voxel is on the boundary
          CFace1(idx).bnd=CFace6(idx).val*abs(zN/2-k)*h/sqrt((xL/2-i)^2+...
                    (yM/2-j)^2+(zN/2-k)^2);%Mixed boundary condition where
                %the normal derivative of the potential is a function of the
                %cos of the angle of the radial vector to the source
      else
          CFace1(idx).bnd=0;
      end
      
      if  j+1>yM
          CFace2(idx).bnd=CFace4(idx).val*abs(yM/2-j)*h/sqrt((xL/2-i)^2+...
                    (yM/2-j)^2+(zN/2-k)^2);%Mixed boundary condition where 
                %the normal derivative of the potential is a function of the
                %cos of the angle of the radial vector to the source
      else
          CFace2(idx).bnd=0;
      end
          
      if i-1==0
          CFace3(idx).bnd=CFace5(idx).val*abs(xL/2-i)*h/sqrt((xL/2-i)^2+...
                    (yM/2-j)^2+(zN/2-k)^2);%Mixed boundary condition where
                %the normal derivative of the potential is a function of the
                %cos of the angle of the radial vector to the source
      else
          CFace3(idx).bnd=0;
      end
      
      if j-1==0
       CFace4(idx).bnd=CFace2(idx).val*abs(yM/2-j)*h/sqrt((xL/2-i)^2+...
                    (yM/2-j)^2+(zN/2-k)^2);%Mixed boundary condition where
                %the normal derivative of the potential is a function of the
                %cos of the angle of the radial vector to the source
      else
          CFace4(idx).bnd=0;
      end
          
      if i+1>xL
       CFace5(idx).bnd=CFace3(idx).val*abs(xL/2-i)*h/sqrt((xL/2-i)^2+...
                    (yM/2-j)^2+(zN/2-k)^2);%Mixed boundary condition where
                %the normal derivative of the potential is a function of the
                %cos of the angle of the radial vector to the source
      else
          CFace5(idx).bnd=0;
      end
      
      if k+1>zN
       CFace6(idx).bnd=CFace1(idx).val*abs(zN/2-k)*h/sqrt((xL/2-i)^2+...
                    (yM/2-j)^2+(zN/2-k)^2);%Mixed boundary condition where 
                %the normal derivative of the potential is a function of 
                %the cos of the angle of the radial vector to the source
      else
          CFace6(idx).bnd=0;
      end
            CSelf(idx).val=-(CFace1(idx).val+CFace2(idx).val...
                +CFace3(idx).val+CFace4(idx).val+CFace5(idx).val...
                +CFace6(idx).val)-(CFace1(idx).bnd+CFace2(idx).bnd...
                +CFace3(idx).bnd+CFace4(idx).bnd+CFace5(idx).bnd...
                +CFace6(idx).bnd);
            CSelf(idx).loc=[idx idx];
            

        end
    end
end


% This code concatenates all the face values together into one matrix of
% triplets (location,location,value) to populate the FD matrix
C1loc=cat(1,CFace1.loc);
C1val=cat(1,CFace1.val);
C1=[C1loc C1val];

C2loc=cat(1,CFace2.loc);
C2val=cat(1,CFace2.val);
C2=[C2loc C2val];

C3loc=cat(1,CFace3.loc);
C3val=cat(1,CFace3.val);
C3=[C3loc C3val];

C4loc=cat(1,CFace4.loc);
C4val=cat(1,CFace4.val);
C4=[C4loc C4val];

C5loc=cat(1,CFace5.loc);
C5val=cat(1,CFace5.val);
C5=[C5loc C5val];

C6loc=cat(1,CFace6.loc);
C6val=cat(1,CFace6.val);
C6=[C6loc C6val];

CSelfloc=cat(1,CSelf.loc);
CSelfval=cat(1,CSelf.val);
CS=[CSelfloc CSelfval];

C=cat(1,C1,C2,C3,C4,C5,C6,CS);

cond=C(:,1)==-1;
 %Removes all rows where the first element is -1.  These rows would fall
 %outside the bounds of the FD matrix.
C(cond,:)=[];

FDMatrix=sparse(C(:,1),C(:,2),C(:,3));

end

