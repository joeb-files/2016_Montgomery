function [ GM ] = GM_builder(xL,yM,zN, GM_Name)
%This function builds a 3D geometric model of a space to be measured with
%the four electrode method (4EM)
%xL, yM, zN are the matrix sizes of the 3D matrix.  GM_Name is the name
%that will be assigned to the final model matrix
%   Any number of conductivity tensors can be established here
sigma1=[.2 0 0;0 .2 0;0 0 .2];%isotropic conductivity tensor with 
%conductivity=0.2
sigma2=[0.1 0 0;0 0.5 0;0 0 0.1];%anisotropic conductivity tensor with y 
%direction conductivity =0.5 and transverse conductivities =0.1

%% Geometric Model.  This code populates a structure called GM with
%diagonalized conductivity tensors. The code creates a layered structure 
%with an an anisotropic layer surrounded by two isotropic layers.  Control
%conductivities by editing the tensors in the section above.  Control the
%layer thickness by changing the bounds on the slice loops below.  More
%complicated structures can be created by changing the for loops or
%importing conductivity tensors into a similar structure

rows=xL;columns=yM;slices=zN;
GM=cell(rows,columns,slices);
for row=1:rows
    for column=1:columns
        for slice=1:35
           
            GM{row,column,slice}=sigma1;
        end
    end
end
for row=1:rows
    for column=1:columns
        for slice=36:55
            GM{row,column,slice}=sigma2;
        end
    end
end
for row=1:rows
    for column=1:columns
        for slice=56:slices
            GM{row,column,slice}=sigma1;
    end
    end
end

save(strcat(GM_Name,'.mat'),'GM')





