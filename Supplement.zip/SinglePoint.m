function [potentialdiff,xRes]=SinglePoint(Direction,h,ProbeSpacing,...
    ProbeDepth,FDMatrix,xL,yM,zN)

%This function computes the potential difference between probes 2 and 3 of
%a four electrode conductivity measurement (4EM)system.  The inputs are: 
%Direction: (1=x, 2=y,3=z) of alignment of the probe axis.
%h: spacing of the voxels (nominally 0.1 mm)
%ProbeSpacing:  Distance between the probes (nominally 1.5mm)
%ProbeDepth:  Z depth of the probe in the medium (tenths of mm)
%FDMatrix:  The finite difference matrix (Created by SetUpFDMatrix.m)
%xL,yM, zN, the number of voxels in the x y and z directions.  xL=yM=zN.
%The outputs are the potential difference between probes 2 and 3, and an
%array of potentials (xRes) in the geometry of GM.

%This code sets up the source vector S to be the size of the FD matrix
lengthS=sub2ind([xL yM zN],xL,yM,zN);
S=zeros(lengthS,1);

%Set the center of the probe to the middle of the medium in the x and y
%directions and the z depth specified by ProbeDepth
ProbeCenter=[round(xL/2) round(yM/2) ProbeDepth];

%Specify the location of each probe from ProbeCenter along the Direction
%axis
Probe1=round(ProbeCenter(Direction)+3*ProbeSpacing/(2*h));
Probe2=round(ProbeCenter(Direction)+ProbeSpacing/(2*h));
Probe3=round(ProbeCenter(Direction)-ProbeSpacing/(2*h));
Probe4=round(ProbeCenter(Direction)-3*ProbeSpacing/(2*h));

%Depending on Direction, specify the location of probes 1 and 4 (point
%current sources of 10 and -10 units)
if Direction==1
    S(sub2ind([xL yM zN],Probe1,ProbeCenter(2),ProbeCenter(3)))=10;
    S(sub2ind([xL yM zN],Probe4,ProbeCenter(2),ProbeCenter(3)))=-10;
    
    %x=symmlq(FDMatrix,S,[],1000) (this method proved not to be optimum);
    % x=gmres(FDMatrix,S,[],[],500)(this method proved not to be optimum);
    x=qmr(FDMatrix,S,[],1000);%Solve sparse matrix system
    xRes=reshape(x,[xL yM zN]);%Reshape the output to the geometry of GM
    potentialdiff=xRes(Probe3,ProbeCenter(2),ProbeCenter(3))...
        -xRes(Probe2,ProbeCenter(2),ProbeCenter(3)); %Measure potential 
    %between probes 2 and 3
elseif Direction==2
    S(sub2ind([xL yM zN],ProbeCenter(1),Probe1,ProbeCenter(3)))=10;%Set 
    %point current source location
    S(sub2ind([xL yM zN],ProbeCenter(1),Probe4,ProbeCenter(3)))=-10;%Set 
    %point current source location
    
    %x=symmlq(FDMatrix,S,[],1000);
    % x=gmres(FDMatrix,S,[],[],500);
    x=qmr(FDMatrix,S,[],1000);
    xRes=reshape(x,[xL yM zN]);
    potentialdiff=xRes(ProbeCenter(1),Probe3,ProbeCenter(3))...
        -xRes(ProbeCenter(1),Probe2,ProbeCenter(3)); %Measure potential
elseif Direction==3
    S(sub2ind([xL yM zN],ProbeCenter(1),ProbeCenter(2),Probe1))=10;%Set 
    %point current source location
    S(sub2ind([xL yM zN],ProbeCenter(1),ProbeCenter(2),Probe4))=-10;%Set
    %point current source location
    
    %x=symmlq(FDMatrix,S,[],1000);
    % x=gmres(FDMatrix,S,[],[],500);
    x=qmr(FDMatrix,S,[],1000);
    xRes=reshape(x,[xL yM zN]);
    assignin('base','xRes',xRes)
    potentialdiff=xRes(ProbeCenter(1),ProbeCenter(2),Probe3)...
        -xRes(ProbeCenter(1),ProbeCenter(2),Probe2); %Measure potential
end

end

